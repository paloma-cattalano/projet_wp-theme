<?php get_header(); ?>

<section class="page-header front-page-header
   <?php if(get_theme_mod('banner_image')) : echo 'boxy-header'; endif; ?>"
  style="background-image: url('<?php echo get_theme_mod('banner_image'); ?>');">

  <h1 class="page-title" style="font-size:
    <?php echo get_theme_mod('fp_texts_title_size'); ?>px;">
    <?php echo get_theme_mod('fp_texts_title'); ?>
  </h1>

      <a href="<?php echo get_theme_mod('fp_button_url'); ?>">
      <button type="button" class="call-to-action <?php echo get_theme_mod('fp_button_style'); ?>">
        <?php echo get_theme_mod('fp_button_text'); ?>
      </button>
  </a>

  </section>

  <main class="container front-content">
    <section class="custom-presentation">


      <div class="custom-presentation-infos">

       <h2 class="custom-title">
         <?php echo get_theme_mod('fp_title_description'); ?>
        </h2>


        <p class="custom-content">
        <?php echo get_theme_mod('fp_texts_description'); ?>
        </p>

        <a href="index.php">

          <button type="button" class="call-to-action <?php echo get_theme_mod('fp_button_3'); ?>">
            <?php echo get_theme_mod('fp_button_text_3'); ?>
          </button>
        
        </a>



      </div>

    </section>

    <section class="custom-blocks">
      <div class="custom-block">
        <i class="fas fa-birthday-cake fa-3x"></i>
        <h3 class="custom-title"><?php echo get_theme_mod('custom-title-1'); ?></h3>
        <p class="custom-content">
         <?php echo get_theme_mod('custom-text-1'); ?>
        </p>
      </div>

      <div class="custom-block">
        <i class="fas fa-music fa-3x"></i>
        <h3 class="custom-title"><?php echo get_theme_mod('custom-title-2'); ?></h3>
        <p class="custom-content">
          <?php echo get_theme_mod('custom-text-2'); ?>
        </p>
      </div>

      <div class="custom-block">
        <i class="fas fa-ticket-alt fa-3x"></i>
        <h3 class="custom-title"><?php echo get_theme_mod('custom-title-3'); ?></h3>
        <p class="custom-content">
          <?php echo get_theme_mod('custom-text-3'); ?>
        </p>
      </div>

    </section>
    <section class="custom-section">
      <blockquote class="star-quote">
        <p class="quote-content" >
          <?php echo get_theme_mod('fp_quote_text'); ?>
        </p>
        <cite class="quote-footer">
          <?php echo get_theme_mod('fp_quote_source'); ?>
        </cite>
      </blockquote>
    </section>
  </main>

  <?php get_footer(); ?>

</body>
</html>
